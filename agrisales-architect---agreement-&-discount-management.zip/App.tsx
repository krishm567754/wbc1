
import React, { useState, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, Search, Settings, TrendingUp, Calendar, Package, 
  PlusCircle, X, FileText, Trash2, RefreshCw, Upload, Info, 
  CheckCircle2, Loader2, Users, Bell, ArrowRight, Lock, Key, LogOut,
  AlertTriangle, Database, History, HardDrive, Layers, Download, Share2, Eye, Clock
} from 'lucide-react';
import { engine } from './services/dataService.ts';
import { Agreement, DashboardStats, ProductDiscountView, SourceMetadata, SlabRule } from './types.ts';

// --- Shared Components ---

const Modal = ({ isOpen, onClose, title, children }: any) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-400">
            <X size={20} />
          </button>
        </div>
        <div className="p-8 max-h-[85vh] overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon: Icon, colorClass }: any) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-start justify-between">
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{title}</p>
      <h3 className="text-2xl font-bold mt-2 text-slate-800">{value}</h3>
    </div>
    <div className={`p-3 rounded-lg ${colorClass}`}>
      <Icon size={20} />
    </div>
  </div>
);

// --- Pages ---

const DashboardPage = ({ refreshTrigger, onRefresh, isAdmin }: { refreshTrigger: number, onRefresh: () => void, isAdmin: boolean }) => {
  const [agreements, setAgreements] = useState<Agreement[]>([]);
  const [statsMap, setStatsMap] = useState<Record<string, DashboardStats>>({});

  useEffect(() => {
    const data = engine.getAgreements();
    const sMap: Record<string, DashboardStats> = {};
    data.forEach(a => sMap[a.id] = engine.getAgreementStats(a));
    setAgreements(data);
    setStatsMap(sMap);
  }, [refreshTrigger]);

  const handleDelete = (id: string) => {
    if (!isAdmin) return;
    if (confirm("Delete agreement?")) { engine.deleteAgreement(id); onRefresh(); }
  };

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">Active Accounts</h2>
          <p className="text-slate-500 font-medium italic">Tracking target volume vs actual billed litres.</p>
        </div>
        <button onClick={onRefresh} className="p-3 bg-white border border-slate-200 rounded-xl hover:bg-emerald-50 text-emerald-600 transition-all shadow-sm">
          <RefreshCw size={20} />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard title="Global Target" value={`${agreements.reduce((s, a) => s + a.targetVolumeLitre, 0).toLocaleString()} L`} icon={Package} colorClass="bg-blue-50 text-blue-600" />
        <StatCard title="Total Achieved" value={`${(Object.values(statsMap) as any).reduce((s: any, st: any) => s + st.achievedVolume, 0).toLocaleString()} L`} icon={TrendingUp} colorClass="bg-emerald-50 text-emerald-600" />
        <StatCard title="Agreements" value={agreements.length} icon={Users} colorClass="bg-indigo-50 text-indigo-600" />
        <StatCard title="Expiring Soon" value={(Object.values(statsMap) as any).filter((s: any) => s.isExpiringSoon).length} icon={Bell} colorClass="bg-orange-50 text-orange-600" />
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-separate border-spacing-0">
            <thead>
              <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <th className="px-8 py-5 border-b border-slate-100">Customer</th>
                <th className="px-8 py-5 border-b border-slate-100">Period</th>
                <th className="px-8 py-5 border-b border-slate-100">Target</th>
                <th className="px-8 py-5 border-b border-slate-100 text-emerald-600 font-black">Achieved Vol</th>
                <th className="px-8 py-5 border-b border-slate-100">Progress</th>
                {isAdmin && <th className="px-8 py-5 border-b border-slate-100 text-center">Manage</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {agreements.length === 0 ? (
                <tr><td colSpan={6} className="p-20 text-center text-slate-300 font-bold italic">No agreements found. Upload one in Admin.</td></tr>
              ) : agreements.map(a => {
                const s = statsMap[a.id];
                if (!s) return null;
                return (
                  <tr key={a.id} className="group hover:bg-emerald-50/20 transition-all">
                    <td className="px-8 py-5">
                      <div className="font-bold text-slate-800 text-sm leading-tight">{a.customerName}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-1 uppercase tracking-tighter">{a.customerCode}</div>
                    </td>
                    <td className="px-8 py-5 text-xs font-bold text-slate-500">{a.startDate} <ArrowRight size={10} className="inline mx-1"/> {a.endDate}</td>
                    <td className="px-8 py-5 font-mono text-sm font-bold text-slate-600">{a.targetVolumeLitre.toLocaleString()} L</td>
                    <td className="px-8 py-5 font-mono text-sm font-black text-emerald-600 bg-emerald-50/30">{s.achievedVolume.toLocaleString()} L</td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div className={`h-full transition-all duration-1000 ${s.progressPercentage >= 100 ? 'bg-emerald-600' : 'bg-emerald-400'}`} style={{ width: `${Math.min(100, s.progressPercentage)}%` }} />
                        </div>
                        <span className="text-[11px] font-black text-slate-500">{s.progressPercentage.toFixed(1)}%</span>
                      </div>
                    </td>
                    {isAdmin && (
                      <td className="px-8 py-5 text-center">
                        <button onClick={() => handleDelete(a.id)} className="p-2.5 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"><Trash2 size={18} /></button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const ProductSearchPage = () => {
  const [query, setQuery] = useState('RX SUPER');
  const [results, setResults] = useState<ProductDiscountView[]>([]);
  const [selected, setSelected] = useState<ProductDiscountView | null>(null);

  const handleSearch = () => {
    const data = engine.searchProducts(query);
    setResults(data);
    setSelected(data[0] || null);
  };

  useEffect(handleSearch, [query]);

  return (
    <div className="p-8 space-y-8 animate-in slide-in-from-bottom-2">
      <div className="max-w-3xl space-y-4">
        <h2 className="text-2xl font-black text-slate-800 tracking-tight">Real-Time Payback Lookup</h2>
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={22} />
            <input type="text" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search Product or SKU..." className="w-full pl-12 pr-4 py-4 rounded-2xl border border-slate-200 shadow-sm focus:ring-2 focus:ring-emerald-500 outline-none font-medium" />
          </div>
          <button onClick={handleSearch} className="bg-emerald-600 text-white px-10 py-4 rounded-2xl font-black shadow-xl hover:bg-emerald-700 transition-all">Search</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {results.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-3xl border border-dashed border-slate-200 text-slate-400 italic">No products found for this search in your agreements.</div>
          ) : results.map((r, i) => (
            <button key={i} onClick={() => setSelected(r)} className={`w-full p-6 flex justify-between items-center rounded-2xl border transition-all text-left ${selected === r ? 'bg-emerald-50 border-emerald-300 ring-2 ring-emerald-50 shadow-md' : 'bg-white border-slate-200 hover:border-emerald-300 shadow-sm'}`}>
              <div className="flex gap-4">
                <div className="p-4 bg-slate-50 text-slate-400 rounded-2xl"><Package size={28} /></div>
                <div>
                  <h4 className="font-bold text-slate-800 text-lg leading-tight">{r.matchedProductName}</h4>
                  <p className="text-[11px] text-slate-400 font-black uppercase mt-2 tracking-widest">{r.customerName}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-black text-emerald-600">
                   ₹{r.baseDiscount} <span className="text-slate-300 font-normal">+</span> ₹{r.slabDiscount} 
                   <span className="text-sm font-black ml-2 px-3 py-1 bg-emerald-100 rounded-lg">₹{r.totalDiscount}/L</span>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="lg:col-span-1">
          {selected && (
            <div className="bg-white rounded-[2rem] border border-slate-200 shadow-2xl overflow-hidden sticky top-24">
              <div className="p-8 bg-slate-900 text-white">
                <h3 className="font-black text-xl leading-tight">{selected.matchedProductName}</h3>
                <p className="text-emerald-400 text-[10px] mt-2 uppercase font-black tracking-widest">{selected.customerName}</p>
              </div>
              <div className="p-8 space-y-8">
                <div className="space-y-4">
                   <div className="flex justify-between items-center px-6 py-5 bg-slate-50 rounded-2xl border border-slate-100">
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Base Rate</span>
                    <span className="font-mono font-black text-slate-800 text-2xl">₹{selected.baseDiscount}</span>
                  </div>
                  <div className="flex justify-between items-center px-6 py-5 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                    <div>
                      <span className="text-xs font-black text-emerald-800 uppercase tracking-widest">Slab Bonus</span>
                      <div className="text-[9px] font-black text-emerald-500 uppercase mt-1">Achieved: {selected.achievedVolume.toLocaleString()}L</div>
                    </div>
                    <span className="font-mono font-black text-emerald-600 text-2xl">+ ₹{selected.slabDiscount}</span>
                  </div>
                  <div className="pt-8 text-center">
                    <div className="bg-emerald-600 p-8 rounded-[2.5rem] shadow-xl">
                      <div className="text-[10px] font-black text-emerald-100 uppercase tracking-[0.4em] mb-4 text-center">Final Credit Rate</div>
                      <div className="text-6xl font-black text-white tracking-tighter">₹{selected.totalDiscount}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const AdminPage = ({ onAgreementAdded, logout }: { onAgreementAdded: () => void, logout: () => void }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [customTag, setCustomTag] = useState('Current');
  const [sources, setSources] = useState<SourceMetadata[]>([]);
  const [newAgr, setNewAgr] = useState<Partial<Agreement>>({
    customerName: '', customerCode: '', startDate: '', endDate: '', targetVolumeLitre: 0, products: [], slabs: []
  });

  const agrFileRef = useRef<HTMLInputElement>(null);
  const salesFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setSources(engine.getSources());
  }, [isUploading]);

  const handleClearSource = (tag: string) => {
    if (window.confirm(`Are you sure you want to delete all data associated with the tag "${tag}"?`)) {
      engine.clearSource(tag);
      setSources(engine.getSources());
      onAgreementAdded();
    }
  };

  const handleXLSXUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const buffer = event.target?.result as ArrayBuffer;
      await engine.processSalesXLSX(buffer, customTag, file.name);
      setIsUploading(false);
      onAgreementAdded();
      setSources(engine.getSources());
      alert(`Sales file "${file.name}" processed successfully under "${customTag}".`);
    };
    reader.readAsArrayBuffer(file);
  };

  const handleBackup = () => {
    const data = engine.exportSystemState();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `castrol_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const ok = engine.importSystemState(ev.target?.result as string);
      if (ok) { onAgreementAdded(); setSources(engine.getSources()); alert("Data Import Successful!"); }
      else alert("Invalid backup file format.");
    };
    reader.readAsText(file);
  };

  const handleAgreementPDF = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsExtracting(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = (reader.result as string).split(',')[1];
        const extracted = await engine.extractAgreementFromPDF(base64);
        setNewAgr(prev => ({ ...prev, ...extracted }));
      } catch (err) { alert("AI Extraction error."); }
      finally { setIsExtracting(false); }
    };
    reader.readAsDataURL(file);
  };

  const saveAgreement = (e: React.FormEvent) => {
    e.preventDefault();
    const a: Agreement = {
      id: `AGR-${Date.now()}`,
      customerName: newAgr.customerName || 'New Account',
      customerCode: (newAgr.customerCode || '').trim().toUpperCase().replace(/\s+/g, ''),
      startDate: newAgr.startDate || '',
      endDate: newAgr.endDate || '',
      targetVolumeLitre: newAgr.targetVolumeLitre || 0,
      products: newAgr.products || [],
      slabs: newAgr.slabs?.length ? newAgr.slabs.map((s,i) => ({ ...s, id: `sl-${i}` })) : [{ id: 'f25', minVol: 0, maxVol: Infinity, extraDiscount: 25 }]
    };
    engine.addAgreement(a);
    setIsModalOpen(false);
    onAgreementAdded();
  };

  return (
    <div className="p-8 space-y-12 animate-in zoom-in-95">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">System Administration</h2>
          <p className="text-slate-500 font-medium italic">Manage agreements, sales files, and data backups.</p>
        </div>
        <div className="flex gap-4">
           <button onClick={handleBackup} className="flex items-center gap-2 px-6 py-4 bg-emerald-50 text-emerald-700 rounded-2xl font-black border border-emerald-100 hover:bg-emerald-100 transition-all">
             <Download size={20} /> Export Backup
           </button>
           <button onClick={() => logout()} className="flex items-center gap-2 px-6 py-4 bg-white border border-slate-200 rounded-2xl font-black text-slate-400 hover:text-red-500 transition-all">
             <LogOut size={20} /> Logout
           </button>
           <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-8 py-4 bg-slate-900 text-white rounded-2xl font-black shadow-2xl hover:scale-[1.02] transition-all">
             <PlusCircle size={20} /> New Agreement
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Data Ingestion */}
        <div className="space-y-8">
          <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl"><Upload size={28}/></div>
              <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest">Load Sales Data</h3>
            </div>
            
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Period Identifier (e.g. Current, Jan-25)</label>
              <div className="flex gap-2">
                <input type="text" value={customTag} onChange={e => setCustomTag(e.target.value)} className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Enter tag name..." />
                <button onClick={() => setCustomTag('Current')} className={`px-4 rounded-xl border font-black text-[10px] uppercase transition-all ${customTag.toLowerCase() === 'current' ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-50 text-slate-400'}`}>Set Default</button>
              </div>
            </div>
            
            <input type="file" accept=".xlsx, .xls" className="hidden" ref={salesFileRef} onChange={handleXLSXUpload} />
            <button onClick={() => salesFileRef.current?.click()} disabled={isUploading} className="w-full py-16 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center gap-4 hover:border-blue-500 hover:bg-blue-50 transition-all group shadow-inner">
              {isUploading ? <Loader2 className="animate-spin text-blue-600" size={48} /> : <Database className="text-slate-300 group-hover:text-blue-500" size={48} />}
              <span className="text-xs font-black uppercase text-slate-400 group-hover:text-blue-600">{isUploading ? 'Engine Parsing...' : `Load XLSX to "${customTag}"`}</span>
            </button>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-xl">
             <div className="flex items-center gap-4 mb-4">
                <Share2 className="text-emerald-400" />
                <h3 className="font-black uppercase tracking-widest text-sm">Team Data Sync</h3>
             </div>
             <p className="text-slate-400 text-[11px] mb-6 font-medium leading-relaxed">
               This app runs in your browser. To share agreements and sales with others, export a backup and tell them to import it on their device.
             </p>
             <div className="flex flex-col gap-3">
               <input type="file" accept=".json" className="hidden" id="import-state" onChange={handleImport} />
               <label htmlFor="import-state" className="block w-full text-center py-4 bg-emerald-500 hover:bg-emerald-400 text-emerald-900 font-black rounded-2xl cursor-pointer transition-all shadow-lg uppercase tracking-widest text-xs">Import Database File</label>
             </div>
          </div>
        </div>

        {/* Right Column: File Inventory & Management */}
        <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-8 flex flex-col">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl"><HardDrive size={28}/></div>
              <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest">File Inventory</h3>
            </div>
            <div className="text-[10px] font-black bg-indigo-100 text-indigo-700 px-3 py-1.5 rounded-full uppercase">{sources.length} Uploads</div>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto max-h-[500px] pr-2 custom-scrollbar">
            {sources.length === 0 ? (
               <div className="flex flex-col items-center justify-center h-64 text-slate-300 gap-4 opacity-50">
                  <Database size={48} />
                  <p className="text-sm font-bold italic uppercase tracking-tighter">No files in system</p>
               </div>
            ) : sources.map((s, idx) => (
               <div key={idx} className="p-5 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-between group transition-all hover:border-indigo-200 hover:bg-indigo-50/10">
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="shrink-0 p-3 bg-white rounded-xl shadow-sm border border-slate-100">
                       <FileText size={20} className="text-indigo-600" />
                    </div>
                    <div className="min-w-0">
                       <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md font-black uppercase">{s.tag}</span>
                          <span className="text-xs font-bold text-slate-800 truncate">{s.filename}</span>
                       </div>
                       <div className="flex items-center gap-3 text-[10px] text-slate-400 font-medium">
                          <span className="flex items-center gap-1"><Users size={12}/> {s.recordCount} records</span>
                          <span className="flex items-center gap-1"><Clock size={12}/> {s.uploadDate}</span>
                       </div>
                    </div>
                  </div>
                  <button onClick={() => handleClearSource(s.tag)} className="shrink-0 p-3 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100">
                    <Trash2 size={18} />
                  </button>
               </div>
            ))}
          </div>
          
          <div className="pt-6 border-t border-slate-100">
             <div className="p-6 bg-slate-50 rounded-3xl flex items-center justify-between">
                <div>
                   <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Total System Records</span>
                   <span className="text-2xl font-black text-slate-800 font-mono">
                     {sources.reduce((sum, s) => sum + s.recordCount, 0).toLocaleString()}
                   </span>
                </div>
                <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                   <TrendingUp className="text-emerald-500" size={24} />
                </div>
             </div>
          </div>
        </div>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Agreement Setup">
        <form onSubmit={saveAgreement} className="space-y-6">
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl">
            <input type="file" accept="application/pdf" className="hidden" ref={agrFileRef} onChange={handleAgreementPDF} />
            <button type="button" onClick={() => agrFileRef.current?.click()} className="w-full py-4 bg-white border-2 border-dashed border-slate-200 rounded-xl text-slate-500 font-bold hover:border-emerald-500 transition-all flex items-center justify-center gap-2">
              <FileText size={18} /> {isExtracting ? 'AI Analyzing PDF...' : 'Scan PDF Agreement'}
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase">Customer Code (To match Sales)</label>
              <input required type="text" value={newAgr.customerCode || ''} onChange={e => setNewAgr({...newAgr, customerCode: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500 outline-none uppercase" placeholder="e.g. WAPRA-BKN" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase">Customer Name</label>
              <input required type="text" value={newAgr.customerName || ''} onChange={e => setNewAgr({...newAgr, customerName: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="e.g. WAPRA Workshop" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase">Start Date</label>
              <input required type="date" value={newAgr.startDate || ''} onChange={e => setNewAgr({...newAgr, startDate: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase">End Date</label>
              <input required type="date" value={newAgr.endDate || ''} onChange={e => setNewAgr({...newAgr, endDate: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase">Total Volume Target (L)</label>
            <input required type="number" value={newAgr.targetVolumeLitre || 0} onChange={e => setNewAgr({...newAgr, targetVolumeLitre: parseInt(e.target.value)})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" />
          </div>

          <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-2xl space-y-4">
             <div className="flex items-center gap-2 text-emerald-800">
               <Layers size={18} />
               <span className="text-[10px] font-black uppercase tracking-widest">Incentive Slabs (Confirm ₹/L)</span>
             </div>
             {newAgr.slabs?.map((slab, i) => (
               <div key={i} className="grid grid-cols-3 gap-2">
                 <input type="number" placeholder="Min Vol" value={slab.minVol} onChange={e => { const s = [...(newAgr.slabs || [])]; s[i].minVol = parseInt(e.target.value); setNewAgr({...newAgr, slabs: s}); }} className="px-3 py-2 text-xs border rounded-lg" />
                 <input type="number" placeholder="Max Vol" value={slab.maxVol} onChange={e => { const s = [...(newAgr.slabs || [])]; s[i].maxVol = parseInt(e.target.value); setNewAgr({...newAgr, slabs: s}); }} className="px-3 py-2 text-xs border rounded-lg" />
                 <input type="number" placeholder="₹/L Rate" value={slab.extraDiscount} onChange={e => { const s = [...(newAgr.slabs || [])]; s[i].extraDiscount = parseInt(e.target.value); setNewAgr({...newAgr, slabs: s}); }} className="px-3 py-2 text-xs border border-emerald-300 font-bold bg-white" />
               </div>
             ))}
             <button type="button" onClick={() => setNewAgr({...newAgr, slabs: [...(newAgr.slabs || []), { id: `s-${Date.now()}`, minVol: 0, maxVol: 999999, extraDiscount: 0 }]})} className="text-[9px] font-black text-emerald-600 uppercase">+ Add Slab Rule</button>
          </div>

          <button type="submit" className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-slate-800 transition-all">Save Agreement</button>
        </form>
      </Modal>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'search' | 'admin'>('dashboard');
  const [isAdmin, setIsAdmin] = useState(false);
  const [loginInput, setLoginInput] = useState('');
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => { if (localStorage.getItem('castrol_admin_auth') === 'true') setIsAdmin(true); }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginInput === 'admin786') { setIsAdmin(true); localStorage.setItem('castrol_admin_auth', 'true'); setLoginInput(''); }
    else alert("Access Denied.");
  };

  const logout = () => { setIsAdmin(false); localStorage.removeItem('castrol_admin_auth'); setActiveTab('dashboard'); };
  const handleRefresh = () => setRefreshTrigger(p => p + 1);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      <nav className="bg-white border-b border-slate-100 sticky top-0 z-30 px-8 py-5 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <div className="bg-emerald-600 text-white p-2.5 rounded-2xl shadow-lg"><TrendingUp size={24} /></div>
          <h1 className="text-xl font-black text-slate-900 tracking-tighter uppercase">Castrol <span className="text-emerald-600 font-normal italic lowercase tracking-normal">Architect</span></h1>
        </div>
        <div className="flex bg-slate-100 p-1.5 rounded-2xl gap-1">
          {(['dashboard', 'search', 'admin'] as const).map(t => (
            <button key={t} onClick={() => setActiveTab(t)} className={`px-8 py-2.5 rounded-xl text-xs font-black uppercase transition-all ${activeTab === t ? 'bg-white shadow-sm text-emerald-600' : 'text-slate-400 hover:text-slate-600'}`}>
              {t === 'admin' && !isAdmin ? <Lock size={12} className="inline mr-1" /> : null}
              {t === 'search' ? 'Incentive Lookup' : t}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-4">
           {isAdmin && <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-4 py-2 rounded-full border border-emerald-100 uppercase tracking-widest flex items-center gap-2"><CheckCircle2 size={12}/> Admin Control</span>}
           <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-300 font-black text-xs">SYS</div>
        </div>
      </nav>

      <main className="flex-1 max-w-7xl mx-auto w-full">
        {activeTab === 'dashboard' && <DashboardPage refreshTrigger={refreshTrigger} onRefresh={handleRefresh} isAdmin={isAdmin} />}
        {activeTab === 'search' && <ProductSearchPage />}
        {activeTab === 'admin' && (
          !isAdmin ? (
            <div className="flex flex-col items-center justify-center h-[70vh] animate-in fade-in duration-500">
               <div className="bg-white p-12 rounded-[2.5rem] shadow-2xl border border-slate-100 w-full max-w-md text-center">
                  <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-inner"><Key size={32}/></div>
                  <h2 className="text-2xl font-black text-slate-800 mb-2 uppercase tracking-tight">Access Control</h2>
                  <p className="text-slate-500 mb-8 font-medium">Please authorize to manage system data.</p>
                  <form onSubmit={handleLogin} className="space-y-4">
                     <input type="password" placeholder="Access Code" value={loginInput} onChange={e => setLoginInput(e.target.value)} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-center text-2xl font-black focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all" />
                     <button type="submit" className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-slate-800 transition-all">Unlock Dashboard</button>
                  </form>
               </div>
            </div>
          ) : ( <AdminPage onAgreementAdded={handleRefresh} logout={logout} /> )
        )}
      </main>

      <footer className="py-12 text-center text-[10px] font-black text-slate-300 uppercase tracking-[0.4em] border-t border-slate-100 bg-white">
        Precise Data Storage • Global Sync Active • v11.0.0
      </footer>
    </div>
  );
}
