
export interface SaleRecord {
  Invoice_No: string;
  Invoice_Date: string; // ISO String
  Customer_Code: string;
  Customer_Name: string;
  Product_SKU: string;
  Product_Name: string;
  Quantity_Litre: number;
  Net_Rate: number;
  Invoice_Value: number;
  Source_File: string; // The tag used to identify the upload period
  Original_Filename?: string; // The actual name of the uploaded file
}

export interface SourceMetadata {
  tag: string;
  filename: string;
  recordCount: number;
  uploadDate: string;
}

export interface SlabRule {
  id: string;
  minVol: number;
  maxVol: number;
  extraDiscount: number;
  productSKU?: string; 
}

export interface AgreementProduct {
  sku: string;
  productName: string;
  baseDiscount: number;
}

export interface Agreement {
  id: string;
  customerCode: string;
  customerName: string;
  startDate: string;
  endDate: string;
  targetVolumeLitre: number;
  products: AgreementProduct[];
  slabs: SlabRule[];
}

export interface DashboardStats {
  achievedVolume: number;
  remainingVolume: number;
  progressPercentage: number;
  isExpiringSoon: boolean;
  daysToExpiry: number;
}

export interface ProductDiscountView {
  matchedProductName: string;
  matchedSKU: string;
  customerName: string;
  customerCode: string;
  baseDiscount: number;
  slabDiscount: number;
  totalDiscount: number;
  achievedVolume: number;
  agreementValid: boolean;
  slabs: SlabRule[];
}
