
import { GoogleGenAI, Type } from "@google/genai";
import { SaleRecord, Agreement, DashboardStats, ProductDiscountView, SlabRule, SourceMetadata } from '../types.ts';
import * as XLSX from 'xlsx';

const STORAGE_KEYS = {
  AGREEMENTS: 'castrol_v10_agreements',
  SALES: 'castrol_v10_sales',
  SOURCES: 'castrol_v10_sources'
};

class SalesDataEngine {
  private sales: SaleRecord[] = [];
  private agreements: Agreement[] = [];
  private sources: SourceMetadata[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const storedAgreements = localStorage.getItem(STORAGE_KEYS.AGREEMENTS);
      const storedSales = localStorage.getItem(STORAGE_KEYS.SALES);
      const storedSources = localStorage.getItem(STORAGE_KEYS.SOURCES);

      if (storedAgreements) this.agreements = JSON.parse(storedAgreements);
      if (storedSales) this.sales = JSON.parse(storedSales);
      if (storedSources) this.sources = JSON.parse(storedSources);
    } catch (e) {
      console.error("Storage load error", e);
    }
  }

  public saveToStorage() {
    localStorage.setItem(STORAGE_KEYS.AGREEMENTS, JSON.stringify(this.agreements));
    localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(this.sales));
    localStorage.setItem(STORAGE_KEYS.SOURCES, JSON.stringify(this.sources));
  }

  public exportSystemState(): string {
    const state = {
      agreements: this.agreements,
      sales: this.sales,
      sources: this.sources,
      exportedAt: new Date().toISOString()
    };
    return JSON.stringify(state);
  }

  public importSystemState(json: string) {
    try {
      const state = JSON.parse(json);
      if (state.agreements) this.agreements = state.agreements;
      if (state.sales) this.sales = state.sales;
      if (state.sources) this.sources = state.sources;
      this.saveToStorage();
      return true;
    } catch (e) {
      return false;
    }
  }

  public async extractAgreementFromPDF(fileBase64: string): Promise<Partial<Agreement>> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [
          { inlineData: { data: fileBase64, mimeType: "application/pdf" } },
          { text: `Analyze this Castrol Agreement. 
          1. Extract 'Customer Code'.
          2. Extract 'startDate' and 'endDate' (YYYY-MM-DD).
          3. Extract 'targetVolumeLitre'.
          4. Identify EXACT slab discount. If text says "35/L total", use 35. 
          Return JSON: customerName, customerCode, targetVolumeLitre, startDate, endDate, products, slabs.` }
        ]
      }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            customerName: { type: Type.STRING },
            customerCode: { type: Type.STRING },
            startDate: { type: Type.STRING },
            endDate: { type: Type.STRING },
            targetVolumeLitre: { type: Type.NUMBER },
            products: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { sku: { type: Type.STRING }, productName: { type: Type.STRING }, baseDiscount: { type: Type.NUMBER } } } },
            slabs: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { minVol: { type: Type.NUMBER }, maxVol: { type: Type.NUMBER }, extraDiscount: { type: Type.NUMBER } } } }
          }
        }
      }
    });
    return JSON.parse(response.text || '{}');
  }

  public async processSalesXLSX(fileBuffer: ArrayBuffer, tag: string, filename: string) {
    const workbook = XLSX.read(fileBuffer, { type: 'array' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json(sheet) as any[];

    if (tag.toLowerCase() === 'current') {
      this.sales = this.sales.filter(s => s.Source_File.toLowerCase() !== 'current');
      this.sources = this.sources.filter(s => s.tag.toLowerCase() !== 'current');
    } else {
      this.sales = this.sales.filter(s => s.Source_File !== tag);
      this.sources = this.sources.filter(s => s.tag !== tag);
    }

    const records: SaleRecord[] = data.map((row, idx) => {
      const allKeys = Object.keys(row);
      const getVal = (synonyms: string[], exclude: string[] = []) => {
        const foundKey = allKeys.find(k => {
          const cleanK = k.toLowerCase().replace(/[\s\-_]/g, '');
          const isExcluded = exclude.some(ex => cleanK.includes(ex.toLowerCase()));
          if (isExcluded) return false;
          return synonyms.some(s => cleanK.includes(s.toLowerCase().replace(/[\s\-_]/g, '')));
        });
        return foundKey ? row[foundKey] : null;
      };

      const rawCode = (
        getVal(['soldto', 'shipto', 'customer', 'custcode', 'custno', 'payer', 'bpcode', 'partner', 'accountnumber'], ['product', 'material', 'sku', 'item']) 
        || getVal(['code'], ['product', 'material', 'sku', 'item'])
      )?.toString() || '';
      
      const cleanCode = rawCode.trim().toUpperCase().replace(/\s+/g, '');
      const rawQty = getVal(['litre', 'lit', 'billedqty', 'volume', 'qty', 'quantity', 'voll'], ['rate', 'price', 'value']);
      const quantity = parseFloat(rawQty || 0);
      const productSKU = (getVal(['sku', 'material', 'article', 'productid'], ['customer', 'soldto']) || '').toString();
      const productName = (getVal(['product', 'description', 'materialtext', 'prodname'], ['customer', 'code']) || '').toString();

      return {
        Invoice_No: (getVal(['inv', 'bill', 'doc', 'invoice', 'document']) || `R-${tag}-${idx}`).toString(),
        Invoice_Date: getVal(['date', 'billing', 'invoice_date', 'posted']) || new Date().toISOString(),
        Customer_Code: cleanCode,
        Customer_Name: (getVal(['custname', 'customername', 'shiptoname', 'soldtoname']) || '').toString(),
        Product_SKU: productSKU,
        Product_Name: productName,
        Quantity_Litre: quantity,
        Net_Rate: parseFloat(getVal(['rate', 'netprice', 'unitprice', 'price']) || 0),
        Invoice_Value: parseFloat(getVal(['value', 'totalamount', 'netvalue']) || 0),
        Source_File: tag,
        Original_Filename: filename
      };
    }).filter(r => r.Customer_Code !== '');

    this.sales = [...this.sales, ...records];
    this.sources.push({
      tag,
      filename,
      recordCount: records.length,
      uploadDate: new Date().toLocaleString()
    });

    this.saveToStorage();
  }

  public clearSource(tag: string) {
    this.sales = this.sales.filter(s => s.Source_File !== tag);
    this.sources = this.sources.filter(s => s.tag !== tag);
    this.saveToStorage();
  }

  public getAgreementStats(agreement: Agreement): DashboardStats {
    const targetCode = agreement.customerCode.trim().toUpperCase().replace(/\s+/g, '');
    const achievedVolume = this.sales
      .filter(s => s.Customer_Code === targetCode)
      .reduce((sum, s) => sum + s.Quantity_Litre, 0);
    const remainingVolume = Math.max(0, agreement.targetVolumeLitre - achievedVolume);
    const progressPercentage = agreement.targetVolumeLitre > 0 ? (achievedVolume / agreement.targetVolumeLitre) * 100 : 0;
    const endDate = new Date(agreement.endDate);
    const today = new Date();
    const diffDays = Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return { achievedVolume, remainingVolume, progressPercentage, isExpiringSoon: diffDays <= 30 && diffDays >= 0, daysToExpiry: diffDays };
  }

  public getSources() { return this.sources; }
  public getAgreements() { return this.agreements; }
  public addAgreement(a: Agreement) { this.agreements.push(a); this.saveToStorage(); }
  public deleteAgreement(id: string) { this.agreements = this.agreements.filter(a => a.id !== id); this.saveToStorage(); }
  public searchProducts(query: string): ProductDiscountView[] {
    const lowerQuery = query.toLowerCase();
    const results: ProductDiscountView[] = [];
    this.agreements.forEach(agr => {
      const matches = agr.products.filter(p => p.sku.toLowerCase().includes(lowerQuery) || p.productName.toLowerCase().includes(lowerQuery));
      matches.forEach(m => results.push(this.calculateDiscountView(agr, m.sku, m.productName)));
    });
    return results;
  }
  private calculateDiscountView(agr: Agreement, sku: string, name: string): ProductDiscountView {
    const stats = this.getAgreementStats(agr);
    const prodInAgr = agr.products.find(p => p.sku === sku);
    const baseDiscount = prodInAgr ? prodInAgr.baseDiscount : 0;
    const activeSlab = [...agr.slabs].sort((a, b) => b.minVol - a.minVol).find(s => stats.achievedVolume >= s.minVol);
    const slabDiscount = activeSlab ? activeSlab.extraDiscount : (agr.slabs[0]?.extraDiscount || 0);
    return { matchedProductName: name, matchedSKU: sku, customerName: agr.customerName, customerCode: agr.customerCode, baseDiscount, slabDiscount, totalDiscount: baseDiscount + slabDiscount, achievedVolume: stats.achievedVolume, agreementValid: true, slabs: agr.slabs };
  }
}

export const engine = new SalesDataEngine();
